using DraftReader.Domain.Entities;
using DraftReader.Domain.Enumerations;
using DraftReader.Domain.Interfaces.Repositories;
using DraftReader.Domain.Interfaces.Services;

namespace DraftReader.Application.Services;

public class DashboardService(
    ISectionRepository sectionRepo,
    IUserRepository userRepo,
    IEmailDeliveryLogRepository logRepo,
    ICommentRepository commentRepo,
    IInvitationRepository invitationRepo,
    IScrivenerProjectRepository projectRepo) : IDashboardService
{
    public async Task<IReadOnlyList<Section>> GetProjectOverviewAsync(
        Guid projectId, CancellationToken ct = default) =>
        await sectionRepo.GetPublishedByProjectIdAsync(projectId, ct);

    public async Task<IReadOnlyList<User>> GetReaderSummaryAsync(
        CancellationToken ct = default) =>
        await userRepo.GetAllBetaReadersAsync(ct);

    public async Task<IReadOnlyList<EmailDeliveryLog>> GetEmailHealthSummaryAsync(
        CancellationToken ct = default) =>
        await logRepo.GetFailedAsync(ct);

    /// <inheritdoc />
    public async Task<IReadOnlyList<NotificationItemDto>> GetRecentNotificationsAsync(
        Guid authorUserId,
        int maxItems = 20,
        CancellationToken ct = default)
    {
        // We fetch a generous pool from each source then merge-sort, because each
        // source has different volume characteristics and we can't do a cross-source
        // ORDER BY in a single query without a view.
        var poolSize = maxItems * 3;

        var commentRowsTask   = commentRepo.GetRecentCommentsForDashboardAsync(authorUserId, poolSize, ct);
        var readerJoinsTask   = invitationRepo.GetRecentlyAcceptedAsync(poolSize, ct);
        var syncEventsTask    = projectRepo.GetRecentlySyncedAsync(poolSize, ct);

        await Task.WhenAll(commentRowsTask, readerJoinsTask, syncEventsTask);

        var items = new List<NotificationItemDto>(poolSize);

        // --- Comments (new root comments + replies to author) ---
        foreach (var row in commentRowsTask.Result)
        {
            if (row.ParentCommentAuthorId == authorUserId)
            {
                // This comment is a reply to one of the author's own comments
                items.Add(NotificationItemDto.ReplyToAuthor(
                    row.CommentAuthorName, row.SectionTitle,
                    row.Body, row.SectionId, row.CreatedAt));
            }
            else if (row.ParentCommentId is null)
            {
                // Root-level comment from a reader
                items.Add(NotificationItemDto.NewComment(
                    row.CommentAuthorName, row.SectionTitle,
                    row.Body, row.SectionId, row.CreatedAt));
            }
            // Replies to other readers' comments are omitted from the author panel
            // (the author doesn't need to know about reader-to-reader threads)
        }

        // --- Reader joined (invitation accepted) ---
        foreach (var (invitation, user) in readerJoinsTask.Result)
        {
            if (invitation.AcceptedAt.HasValue)
                items.Add(NotificationItemDto.ReaderJoined(
                    user.DisplayName, invitation.AcceptedAt.Value));
        }

        // --- Sync completed ---
        foreach (var (project, syncedAt) in syncEventsTask.Result)
        {
            items.Add(NotificationItemDto.SyncCompleted(project.Name, syncedAt));
        }

        return items
            .OrderByDescending(i => i.OccurredAt)
            .Take(maxItems)
            .ToList();
    }
}
