using DraftReader.Application.Services;
using DraftReader.Domain.Entities;

namespace DraftReader.Domain.Interfaces.Services;

public interface IDashboardService
{
    Task<IReadOnlyList<Section>> GetProjectOverviewAsync(Guid projectId, CancellationToken ct = default);
    Task<IReadOnlyList<User>> GetReaderSummaryAsync(CancellationToken ct = default);
    Task<IReadOnlyList<EmailDeliveryLog>> GetEmailHealthSummaryAsync(CancellationToken ct = default);

    /// <summary>
    /// Returns up to <paramref name="maxItems"/> recent activity items for the
    /// author's notifications panel, newest first.
    /// Covers: new reader comments, replies to author, reader joined, sync events.
    /// </summary>
    Task<IReadOnlyList<NotificationItemDto>> GetRecentNotificationsAsync(
        Guid authorUserId,
        int maxItems = 20,
        CancellationToken ct = default);
}
