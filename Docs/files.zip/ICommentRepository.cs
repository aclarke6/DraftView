using DraftReader.Domain.Entities;

namespace DraftReader.Domain.Interfaces.Repositories;

public interface ICommentRepository
{
    Task<Comment?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IReadOnlyList<Comment>> GetRootsBySectionIdAsync(Guid sectionId, CancellationToken ct = default);
    Task<IReadOnlyList<Comment>> GetRepliesByParentIdAsync(Guid parentCommentId, CancellationToken ct = default);
    Task<IReadOnlyList<Comment>> GetByAuthorIdAsync(Guid authorId, CancellationToken ct = default);
    Task<int> CountBySectionIdAsync(Guid sectionId, CancellationToken ct = default);
    Task<IReadOnlyList<Comment>> GetUnreadCommentsForAuthorAsync(Guid authorUserId, DateTime? since, CancellationToken ct = default);
    Task AddAsync(Comment comment, CancellationToken ct = default);

    /// <summary>
    /// Returns recent comments NOT authored by <paramref name="authorUserId"/>,
    /// with the section title and commenter display name pre-joined.
    /// Used exclusively by the dashboard notifications panel.
    /// </summary>
    Task<IReadOnlyList<CommentNotificationRow>> GetRecentCommentsForDashboardAsync(
        Guid authorUserId,
        int take,
        CancellationToken ct = default);
}

/// <summary>
/// Flat projection used by the notifications panel query.
/// Avoids loading full entity graphs into the service layer.
/// </summary>
public sealed record CommentNotificationRow(
    Guid    CommentId,
    Guid    SectionId,
    string  SectionTitle,
    Guid    CommentAuthorId,
    string  CommentAuthorName,
    Guid?   ParentCommentId,
    Guid?   ParentCommentAuthorId,   // null when this IS a root comment
    string  Body,
    DateTime CreatedAt);
