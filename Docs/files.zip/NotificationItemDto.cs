namespace DraftReader.Application.Services;

public enum NotificationEventType
{
    NewComment,
    ReplyToAuthor,
    ReaderJoined,
    SyncCompleted
}

/// <summary>
/// A single item in the author's recent notifications feed.
/// Produced by DashboardService and consumed by the Dashboard view.
/// </summary>
public sealed class NotificationItemDto
{
    public NotificationEventType EventType { get; init; }

    /// <summary>UTC timestamp used for ordering and relative display.</summary>
    public DateTime OccurredAt { get; init; }

    /// <summary>Primary description line shown in the panel.</summary>
    public string Title { get; init; } = string.Empty;

    /// <summary>Optional secondary line (e.g. comment snippet, section name).</summary>
    public string? Detail { get; init; }

    /// <summary>
    /// Optional link target. For comments, links to Author/Section?id=…
    /// For readers, links to Author/Readers.
    /// Null when no deep-link is appropriate.
    /// </summary>
    public string? LinkUrl { get; init; }

    // ------------------------------------------------------------------
    // Factories — keep construction logic out of the service method
    // ------------------------------------------------------------------

    public static NotificationItemDto NewComment(
        string readerName, string sectionTitle,
        string bodySnippet, Guid sectionId, DateTime occurredAt) =>
        new()
        {
            EventType  = NotificationEventType.NewComment,
            OccurredAt = occurredAt,
            Title      = $"{readerName} commented on "{sectionTitle}"",
            Detail     = TruncateSnippet(bodySnippet),
            LinkUrl    = $"/Author/Section/{sectionId}"
        };

    public static NotificationItemDto ReplyToAuthor(
        string readerName, string sectionTitle,
        string bodySnippet, Guid sectionId, DateTime occurredAt) =>
        new()
        {
            EventType  = NotificationEventType.ReplyToAuthor,
            OccurredAt = occurredAt,
            Title      = $"{readerName} replied to your comment on "{sectionTitle}"",
            Detail     = TruncateSnippet(bodySnippet),
            LinkUrl    = $"/Author/Section/{sectionId}"
        };

    public static NotificationItemDto ReaderJoined(
        string readerName, DateTime occurredAt) =>
        new()
        {
            EventType  = NotificationEventType.ReaderJoined,
            OccurredAt = occurredAt,
            Title      = $"{readerName} accepted their invitation",
            Detail     = null,
            LinkUrl    = "/Author/Readers"
        };

    public static NotificationItemDto SyncCompleted(
        string projectName, DateTime occurredAt) =>
        new()
        {
            EventType  = NotificationEventType.SyncCompleted,
            OccurredAt = occurredAt,
            Title      = $"Sync completed for {projectName}",
            Detail     = null,
            LinkUrl    = null
        };

    private static string TruncateSnippet(string body, int maxLength = 80)
    {
        if (string.IsNullOrWhiteSpace(body)) return string.Empty;
        var trimmed = body.Trim();
        return trimmed.Length <= maxLength ? trimmed : trimmed[..maxLength].TrimEnd() + "…";
    }
}
