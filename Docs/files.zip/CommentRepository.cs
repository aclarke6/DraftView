using Microsoft.EntityFrameworkCore;
using DraftReader.Domain.Entities;
using DraftReader.Domain.Interfaces.Repositories;
using DraftReader.Infrastructure.Persistence;

namespace DraftReader.Infrastructure.Persistence.Repositories;

public class CommentRepository(DraftReaderDbContext db) : ICommentRepository
{
    public async Task<Comment?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
        await db.Comments.FindAsync([id], ct);

    public async Task<IReadOnlyList<Comment>> GetRootsBySectionIdAsync(Guid sectionId, CancellationToken ct = default) =>
        await db.Comments
            .Where(c => c.SectionId == sectionId && c.ParentCommentId == null)
            .OrderBy(c => c.CreatedAt)
            .ToListAsync(ct);

    public async Task<IReadOnlyList<Comment>> GetRepliesByParentIdAsync(Guid parentCommentId, CancellationToken ct = default) =>
        await db.Comments
            .Where(c => c.ParentCommentId == parentCommentId)
            .OrderBy(c => c.CreatedAt)
            .ToListAsync(ct);

    public async Task<IReadOnlyList<Comment>> GetByAuthorIdAsync(Guid authorId, CancellationToken ct = default) =>
        await db.Comments
            .Where(c => c.AuthorId == authorId)
            .OrderBy(c => c.CreatedAt)
            .ToListAsync(ct);

    public async Task<int> CountBySectionIdAsync(Guid sectionId, CancellationToken ct = default) =>
        await db.Comments.CountAsync(c => c.SectionId == sectionId && !c.IsSoftDeleted, ct);

    public async Task<IReadOnlyList<Comment>> GetUnreadCommentsForAuthorAsync(
        Guid authorUserId, DateTime? since, CancellationToken ct = default)
    {
        var query = db.Comments
            .Where(c => c.AuthorId != authorUserId && !c.IsSoftDeleted);
        if (since.HasValue)
            query = query.Where(c => c.CreatedAt > since.Value);
        return await query
            .OrderByDescending(c => c.CreatedAt)
            .Take(50)
            .ToListAsync(ct);
    }

    public async Task AddAsync(Comment comment, CancellationToken ct = default) =>
        await db.Comments.AddAsync(comment, ct);

    /// <inheritdoc />
    public async Task<IReadOnlyList<CommentNotificationRow>> GetRecentCommentsForDashboardAsync(
        Guid authorUserId,
        int take,
        CancellationToken ct = default)
    {
        // Join Comments → Sections (for title) → AppUsers (for commenter name).
        // Also left-join to AppUsers again for the parent comment's author, so the
        // service can distinguish "reply to author" from "new root comment".
        var rows = await (
            from c in db.Comments
            join s in db.Sections    on c.SectionId   equals s.Id
            join u in db.AppUsers    on c.AuthorId     equals u.Id
            join parent in db.Comments on c.ParentCommentId equals parent.Id into parentJoin
            from parent in parentJoin.DefaultIfEmpty()
            where c.AuthorId != authorUserId
               && !c.IsSoftDeleted
               && !s.IsSoftDeleted
            orderby c.CreatedAt descending
            select new CommentNotificationRow(
                c.Id,
                c.SectionId,
                s.Title,
                c.AuthorId,
                u.DisplayName,
                c.ParentCommentId,
                parent != null ? parent.AuthorId : (Guid?)null,
                c.Body,
                c.CreatedAt)
        )
        .Take(take)
        .ToListAsync(ct);

        return rows;
    }
}
